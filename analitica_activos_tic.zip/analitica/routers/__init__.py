# analitica/routers/__init__.py
# This file makes 'routers' a Python package
