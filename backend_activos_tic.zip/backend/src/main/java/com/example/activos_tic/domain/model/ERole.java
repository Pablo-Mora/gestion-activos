package com.example.activos_tic.domain.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
