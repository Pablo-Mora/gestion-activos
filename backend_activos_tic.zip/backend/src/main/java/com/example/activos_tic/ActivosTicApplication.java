package com.example.activos_tic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivosTicApplication {

    public static void main(String[] args) {
        SpringApplication.run(ActivosTicApplication.class, args);
    }
}
